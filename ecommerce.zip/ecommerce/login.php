<?php include("includes/db.php"); ?>
<?php include("functions/functions.php"); ?>

<html>
<head>
<style>
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</head>
<body>
<div class="login_box">

<form method ="post" action="">

<table align="left" width="70%">

<tr align="left">

<td colspan="4">

<h2>LOGIN</h2><br/>
<span>DON'T HAVE ACCOUNT? <a href="register.php">REGISTER HERE </a><br/><br/><br/>
 </span>
</td>
</tr>

<tr>
<td width="15%"><b>EMAIL:</b></td>
<td colspan="3"><input type="text" name="email" placeholder="EMAIL" required /></td>
</tr>

<tr>
<td width="15%"><b>PASSWORD:</b></td>
<td colspan="3"><input type="password" name="password" placeholder="PASSWORD" required /></td>
</tr>



<tr align="left">
<td></td>
<td colspan="4">
<input type="submit" name="login" value="Login"/>
</td>
</tr>

</table>
</form>
</div>
</body>
</html>
<?php 

if(isset($_POST['login'])){
	$email = trim($_POST['email']);
	$password = trim($_POST['password']);
	$password=md5($password);
	
	$run_login=mysqli_query($con,"select * from users where password='$password' AND email='$email'");
	
	$check_login=mysqli_num_rows($run_login);
	
	$row_login=mysqli_fetch_array($run_login);
	if($check_login ==0){
		echo "<script>alert('PASSWORD OR EMAIL IS INCORRECT,TRY AGAIN')</script>";
	exit();	
	}
	$ip=get_ip();
	$run_cart=mysqli_query($con,"select * from cart where ip_address='$ip'");
	$check_cart=mysqli_num_rows($run_cart);
	if($check_login>0 AND $check_cart==0){
		$_SESSION['user_id']=$row_login['id'];
		$_SESSION['role']=$row_login['role'];		
		$_SESSION['email']=$email;
	 echo "<script>alert('you logged in successfully')</script>";
	 echo "<script>window.open('all_products.php','_self')</script>";
	 
	
	}else{
		$_SESSION['user_id']=$row_login['id'];
		$_SESSION['role']=$row_login['role'];		
		$_SESSION['email']=$email;
	echo "<script>alert('you logged in successfully')</script>";
	 echo "<script>window.open('all_products.php','_self')</script>";
	 
	}
	
}	

?>

