
<?php include("includes/header.php");?>



<div class="content_wrapper">
<?php if(!isset($_GET['action'])){?>

<div id="sidebar">
<div id="sidebar_title">CATEGORIES</div>
<ul id="cats">

<?php 
getCats();
?>
</ul>

<div id="sidebar_title">BRANDS</div>
<ul id="cats">
<?php 
getBrands();
?>
</ul>

</div><!--#sidebar -->
<div id="content_area">
<?php 
cart();
?>
<div id="products_box">
<?php getPro();?>

<?php get_pro_by_cat_id();?>

<?php get_pro_by_brand_id();?>

</div><!-- product_box -->
</div>
<?php } else {?>
<?php include('login.php');}?>

</div><!--/.content_wrapper-->

<?php include("includes/footer.php");?>