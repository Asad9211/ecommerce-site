<div id="footer">
<h2 style="text-align:center;padding-top:30px">&copy; 2016 - <?php echo date('Y');?> by www.metrixcode.com </h2>
</div>
<!--END MAIN CONTAINER starts here -->
</div>
</body>
</html>
